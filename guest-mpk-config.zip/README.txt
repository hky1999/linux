PVM guest-mpk-config evidence, measured 2026-10-09

These are local publication candidates. No GitHub evidence URL exists yet.
The measurements use the historical PR #29 source 2fc0196a2ebd67261c9cf4f2c3e504516bb5e0bc.
They are not new measurements of the reorganized PR head 1d552964f941.

Reconstruct the historical source by checking out upstream OOT baseline
71b35309f8698bb664dbed0028156c82b8ec79b8, then applying historical-ubuntu7-compat.patch.
Apply this topic's candidate patch separately when comparing variants.
Build against the exact running kernel's headers/config/symbols/compiler.

reproduction-manual.txt is an extract of the measured lab procedure.
harness/ contains the actual harness source, preserving its lab paths and guards.
Adapt the isolated lab paths, CPU pinning and owned-container setup for a new lab.
The harness expects the qualified guest/VMM binaries identified in the manual.
It is not a portable installer or a claim of qualification on other hosts.
build-assets.sh expects merge-sparse.c one directory above harness/.

runtime-evidence/traces/, where present, contains complete decoded trace text,
not the earlier 40-line selected excerpts. Event counts were independently
matched to the recorded JSON summaries before preparing these archives.
The native perf.data files remain retained in the original lab archive.

All archive payload files are covered by SHA256SUMS.
Extract this archive and run: sha256sum -c SHA256SUMS
