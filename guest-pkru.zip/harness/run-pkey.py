#!/usr/bin/env python3
"""Run the same ordinary pkey permission check natively and in a PVM guest."""
import json
import argparse
import pathlib
import re
import subprocess
import time

root=pathlib.Path('/review-oot-perf-20261009')
parser=argparse.ArgumentParser()
parser.add_argument('--case',default='pkey-check-v2')
args=parser.parse_args()
assert re.fullmatch(r'[a-z0-9-]+',args.case)
assert 'init=/root/l1-init.sh' in pathlib.Path('/proc/cmdline').read_text()
assert 'nopku' not in pathlib.Path('/proc/cmdline').read_text().split()
for name in ('firecracker','sandboxd','virtiofsd'):
    assert subprocess.run(['pgrep','-x',name],stdout=subprocess.DEVNULL).returncode!=0
for name in ('kvm_intel','kvm_amd','kvm_pvm','kvm'):
    if pathlib.Path('/sys/module',name).exists():subprocess.run(['rmmod',name],check=True)
subprocess.run(['modprobe','irqbypass'],check=True)
for name in ('kvm.ko','kvm-pvm.ko'):subprocess.run(['insmod',str(root/'modules-baseline'/name)],check=True)
native=subprocess.run([str(root/'pkey-smoke'),'--exit'],capture_output=True,text=True,timeout=10)
assert native.returncode==0 and 'observed=permission_fault' in native.stdout,native.stdout
case=root/args.case
case.mkdir()
config=case/'config.json'
config.write_text(json.dumps({'boot-source':{'kernel_image_path':'/opt/firecracker/vmlinux',
    'initrd_path':str(root/'pkey-guest-initrd.cpio'),
    'boot_args':'console=ttyS0 reboot=k panic=1 pci=off rdinit=/init'},
    'drives':[],'machine-config':{'vcpu_count':1,'mem_size_mib':256,'smt':False}}))
log=case/'guest.log'
with log.open('wb') as output:
    proc=subprocess.Popen(['/usr/local/bin/firecracker','--api-sock',str(case/'fc.sock'),
                           '--config-file',str(config)],stdout=output,stderr=subprocess.STDOUT)
    try:
        deadline=time.monotonic()+40
        while time.monotonic()<deadline:
            text=log.read_text(errors='replace')
            if len([s for s in text.splitlines(keepends=True) if s.startswith('PKEY_SMOKE ') and s.endswith('\n')])==3:break
            assert proc.poll() is None,text[-2000:]
            time.sleep(.05)
        else:raise TimeoutError('pkey guest')
    finally:
        proc.terminate();proc.wait(timeout=10)
lines=[s for s in text.splitlines() if s.startswith(('CPU_STATE ','PKEY_SMOKE '))]
proof={'native':native.stdout.strip(),'guest':lines,'permission_semantics_match':
       all('observed=permission_fault' in s for s in lines if s.startswith('PKEY_SMOKE '))}
(case/'result.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof))
