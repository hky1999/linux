#!/usr/bin/env python3
"""Measure only the owned L1; trace only its QEMU vCPU threads."""
import argparse
import collections
import json
import os
import pathlib
import re
import signal
import select
import subprocess
import sys
import time

ROOT = pathlib.Path('/root/pvm-oot-perf-20261009')
parser = argparse.ArgumentParser()
parser.add_argument('--pilot', action='store_true')
parser.add_argument('--mpk-controls', action='store_true')
parser.add_argument('--traces-only', action='store_true')
parser.add_argument('--mpk-start-round', type=int, default=0)
args = parser.parse_args()
(ROOT / 'runner.pid').write_text(str(__import__('os').getpid()) + '\n')
container = json.loads(subprocess.check_output(['docker', 'inspect', 'pvm-oot-perf-20261009']))[0]
assert container['Config']['Labels']['task'] == 'pvm-oot-perf-20261009'
assert container['State']['Running'] and container['HostConfig']['NetworkMode'] == 'none'
pid = container['State']['Pid']
tids = []
for task in pathlib.Path('/proc', str(pid), 'task').iterdir():
    comm = (task / 'comm').read_text().strip()
    match = re.fullmatch(r'CPU (\d+)/KVM', comm)
    if match:
        index = int(match.group(1))
        assert index < 4
        subprocess.run(['taskset', '-pc', str(100 + index), task.name],
                       stdout=subprocess.DEVNULL, check=True)
        tids.append(int(task.name))
assert len(tids) == 4
(ROOT / 'trace-target.json').write_text(json.dumps({'container_id': container['Id'],
    'qemu_pid': pid, 'vcpu_tids': sorted(tids), 'thread_cpu_pinning': True}, indent=2) + '\n')
ssh = ['nsenter', '-t', str(pid), '-n', 'ssh', '-T', '-o', 'BatchMode=yes',
       '-o', 'StrictHostKeyChecking=no', '-o', 'UserKnownHostsFile=/dev/null',
       '-i', '/root/p2-in/l1-key', '-p', '2222', 'root@127.0.0.1']
(ROOT / 'traces').mkdir(exist_ok=True)
results = json.loads((ROOT / 'measurements.json').read_text()) if args.traces_only else (
    json.loads((ROOT / 'mpk-measurements.json').read_text()) if args.mpk_controls and args.mpk_start_round else [])
trace = None

def start_trace(case_id, phase):
    prefix = ROOT / 'traces' / (case_id + '-' + phase)
    err = (prefix.with_suffix('.perf-stderr')).open('w')
    ctl_read, ctl_write = os.pipe()
    ack_read, ack_write = os.pipe()
    proc = subprocess.Popen(['perf', 'record', '-q', '--delay=-1',
        '--control=fd:' + str(ctl_read) + ',' + str(ack_write),
        '-e', 'kvm:kvm_exit', '-e', 'kvm:kvm_msr',
        '-t', ','.join(map(str, tids)), '-o', str(prefix.with_suffix('.data'))],
        stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=err,
        pass_fds=(ctl_read, ack_write))
    os.close(ctl_read); os.close(ack_write)
    value = proc, err, prefix, ctl_write, ack_read
    control(value, 'enable')
    return value

def control(value, command):
    proc, err, prefix, ctl_write, ack_read = value
    os.write(ctl_write, (command + '\n').encode())
    assert select.select([ack_read], [], [], 15)[0], prefix.with_suffix('.perf-stderr').read_text()
    assert b'ack' in os.read(ack_read, 128), command

def stop_trace(value):
    proc, err, prefix, ctl_write, ack_read = value
    control(value, 'disable')
    control(value, 'stop')
    proc.wait(timeout=15)
    os.close(ctl_write); os.close(ack_read)
    err.close()
    assert proc.returncode == 0, proc.returncode
    target = prefix.with_suffix('.events.txt')
    with target.open('w') as output:
        subprocess.run(['perf', 'script', '--show-lost-events', '-i', str(prefix.with_suffix('.data')),
                        '-F', 'trace:time,tid,event,trace'], stdout=output, check=True)
    text = target.read_text()
    assert 'LOST' not in text and 'lost' not in prefix.with_suffix('.perf-stderr').read_text().lower()
    exits = collections.Counter(re.findall(r'kvm:kvm_exit:\s+reason\s+(\S+)', text))
    msrs = collections.Counter('0x' + format(int(v, 16), 'x') for v in
        re.findall(r'kvm:kvm_msr:\s+msr_read\s+(?:0x)?([0-9a-f]+)\b', text))
    assert sum(exits.values()) > 0, 'No kvm_exit events parsed'
    result = {'scope': 'owned QEMU vCPU TIDs only', 'vcpu_tids': sorted(tids),
              'exit_reasons': dict(exits), 'msr_reads': dict(msrs), 'lost_events': 0,
              'perf_returncode': proc.returncode, 'capture_started_after_enable_ack': True,
              'events_file': str(target.relative_to(ROOT))}
    prefix.with_suffix('.summary.json').write_text(json.dumps(result, indent=2) + '\n')
    return result

def run(variant, work, dirty, case_id, traced=False, guest_nopku=False):
    global trace
    command = 'python3 /review-oot-perf-20261009/run-case.py ' + ' '.join([
        variant, str(work), str(dirty), case_id]) + (' --trace' if traced else '') + (' --guest-nopku' if guest_nopku else '')
    proc = subprocess.Popen(ssh + [command], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, text=True, bufsize=1)
    counts = {}
    stdout = []
    row = None
    for line in proc.stdout:
        stdout.append(line)
        if line.startswith('PHASE_READY '):
            phase = line.split()[1]
            trace = start_trace(case_id, phase)
            proc.stdin.write('GO\n'); proc.stdin.flush()
        elif line.startswith('PHASE_END '):
            phase = line.split()[1]
            counts[phase] = stop_trace(trace)
            trace = None
            proc.stdin.write('ACK\n'); proc.stdin.flush()
        elif line.startswith('RESULT '):
            row = json.loads(line[7:])
    proc.wait(timeout=20)
    (ROOT / (case_id + '.driver.log')).write_text(''.join(stdout) + proc.stderr.read())
    assert proc.returncode == 0 and row and row['status'] == 'PASS', case_id
    row['trace_counts'] = counts
    results.append(row)
    (ROOT / ('mpk-measurements.json' if args.mpk_controls else 'measurements.json')).write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps({'case': case_id, 'status': row['status'],
                     'first_write_us': row['first_write_us'], 'cold_read_us': row['cold_read_us'],
                     'restore_verified': row['all_pages_restore_verified'], 'traces': counts}), flush=True)

try:
    if args.pilot:
        run('baseline', 96, 96, 'pilot-baseline-v3')
    elif args.mpk_controls:
        for round_id in range(args.mpk_start_round, 3):
            for disabled in (False, True):
                run('baseline', 96, 96, 'mpk-v2-r' + str(round_id) + ('-off' if disabled else '-on'), traced=True, guest_nopku=disabled)
    elif not args.traces_only:
        for round_id in range(5):
            order = ['baseline', 'debugctl'] if round_id % 2 == 0 else ['debugctl', 'baseline']
            for variant in order:
                run(variant, 96, 96, 'timing-96-r' + str(round_id) + '-' + variant)
        for work, dirty in [(96, 0), (16, 16), (256, 256)]:
            for round_id in range(3):
                order = ['baseline', 'debugctl'] if round_id % 2 == 0 else ['debugctl', 'baseline']
                for variant in order:
                    run(variant, work, dirty, 'timing-' + str(work) + '-dirty' + str(dirty)
                        + '-r' + str(round_id) + '-' + variant)
    if not args.pilot and not args.mpk_controls:
        for round_id in range(3):
            order = ['baseline', 'debugctl'] if round_id % 2 == 0 else ['debugctl', 'baseline']
            for variant in order:
                for dirty in (0, 96):
                    run(variant, 96, dirty, 'trace-v3-96-dirty' + str(dirty) + '-r'
                        + str(round_id) + '-' + variant, traced=True)
    (ROOT / ('pilot.rc' if args.pilot else 'mpk-controls.rc' if args.mpk_controls else 'qualification.rc')).write_text('0\n')
except BaseException:
    if trace:
        trace[0].send_signal(signal.SIGINT)
        trace[0].wait(timeout=15)
    (ROOT / ('pilot.rc' if args.pilot else 'mpk-controls.rc' if args.mpk_controls else 'qualification.rc')).write_text('1\n')
    raise
