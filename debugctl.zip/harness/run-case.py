#!/usr/bin/env python3
"""One exact-dirty-log Full/Diff/merge/new-process restore case inside the L1."""
import argparse
import fcntl
import hashlib
import http.client
import json
import os
import pathlib
import re
import shutil
import socket
import subprocess
import sys
import time

ROOT = pathlib.Path('/review-oot-perf-20261009')
parser = argparse.ArgumentParser()
parser.add_argument('variant', choices=['baseline', 'debugctl', 'pkru'])
parser.add_argument('work_mib', type=int)
parser.add_argument('dirty_mib', type=int)
parser.add_argument('case_id')
parser.add_argument('--trace', action='store_true')
parser.add_argument('--guest-nopku', action='store_true')
args = parser.parse_args()
assert re.fullmatch(r'[a-z0-9-]+', args.case_id)
assert 0 <= args.dirty_mib <= args.work_mib <= 256
assert 'init=/root/l1-init.sh' in pathlib.Path('/proc/cmdline').read_text()
assert subprocess.check_output(['uname', '-r'], text=True).strip() == '7.0.0-30-generic'
lock = open('/root/oot-perf-test.lock', 'w')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
for name in ('firecracker', 'sandboxd', 'virtiofsd'):
    assert subprocess.run(['pgrep', '-x', name], stdout=subprocess.DEVNULL).returncode != 0
for name in ('kvm_intel', 'kvm_amd', 'kvm_pvm', 'kvm'):
    if pathlib.Path('/sys/module', name).exists():
        subprocess.run(['rmmod', name], check=True)
subprocess.run(['modprobe', 'irqbypass'], check=True)
modules = ROOT / ('modules-' + args.variant)
for name in ('kvm.ko', 'kvm-pvm.ko'):
    subprocess.run(['insmod', str(modules / name)], check=True)
case = ROOT / 'cases' / args.case_id
case.mkdir(parents=True)
memory = pathlib.Path('/dev/shm/oot-perf') / args.case_id
memory.mkdir(parents=True)
vmm = pathlib.Path('/usr/local/bin/firecracker')
if not vmm.exists():
    vmm = pathlib.Path('/opt/firecracker/firecracker')
kernel = pathlib.Path('/opt/firecracker/vmlinux')
expected = {'vmm': 'cc544a9a2fb1b7d7836983b879417b13715740699d6bf720d45735e8e0598231',
            'guest_kernel': '7cc906792775bcff9aa8018cd7016583cf3b6e812ce70df064d76a95ae6aa0e4'}
assert hashlib.sha256(vmm.read_bytes()).hexdigest() == expected['vmm']
assert hashlib.sha256(kernel.read_bytes()).hexdigest() == expected['guest_kernel']
result = {'case_id': args.case_id, 'variant': args.variant,
          'work_mib': args.work_mib, 'dirty_mib': args.dirty_mib,
          'traced': args.trace, 'track_dirty_pages': True,
          'guest_nopku': args.guest_nopku,
          'module_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                            for p in modules.glob('*.ko')},
          'software_sha256': expected, 'api_calls': []}
processes = []

class UnixHTTP(http.client.HTTPConnection):
    def connect(self):
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.settimeout(40)
        self.sock.connect(self.host)

def api(sock, method, endpoint, data):
    start = time.monotonic_ns()
    conn = UnixHTTP(str(sock))
    body = json.dumps(data).encode()
    conn.request(method, endpoint, body, {'Content-Type': 'application/json'})
    response = conn.getresponse()
    content = response.read().decode()
    conn.close()
    result['api_calls'].append({'endpoint': endpoint, 'method': method,
                              'status': response.status, 'us': (time.monotonic_ns()-start)//1000})
    assert 200 <= response.status < 300, (endpoint, response.status, content)

def start_vmm(tag, config=None):
    sock = case / (tag + '.sock')
    log = case / (tag + '.log')
    command = [str(vmm), '--api-sock', str(sock)]
    if config:
        command += ['--config-file', str(config)]
    output = log.open('wb')
    proc = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=output,
                            stderr=subprocess.STDOUT, preexec_fn=lambda: os.sched_setaffinity(0, {0}))
    processes.append((proc, output))
    return proc, sock, log

def wait_log(proc, log, marker, timeout=35):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        text = log.read_text(errors='replace')
        if any(marker in line and line.endswith('\n') for line in text.splitlines(keepends=True)):
            return text
        assert not any(s in text for s in ('DIRTY_VERIFY_BAD', 'Kernel panic', 'invalid opcode')), text[-2500:]
        assert proc.poll() is None, text[-1500:]
        time.sleep(0.01)
    raise TimeoutError(marker + ': ' + log.read_text(errors='replace')[-1500:])

def phase(proc, name, byte, log, marker):
    if args.trace:
        print('PHASE_READY ' + name, flush=True)
        assert sys.stdin.readline().strip() == 'GO'
    proc.stdin.write(byte)
    proc.stdin.flush()
    text = wait_log(proc, log, marker)
    if args.trace:
        print('PHASE_END ' + name, flush=True)
        assert sys.stdin.readline().strip() == 'ACK'
    return text

try:
    config = case / 'config.json'
    config.write_text(json.dumps({
        'boot-source': {'kernel_image_path': str(kernel),
                        'initrd_path': str(ROOT / 'dirty-guest-initrd.cpio'),
                        'boot_args': 'console=ttyS0 reboot=k panic=1 pci=off rdinit=/init '
                                     + 'work_mib=' + str(args.work_mib)
                                     + ' dirty_mib=' + str(args.dirty_mib)
                                     + (' nopku' if args.guest_nopku else '')},
        'drives': [], 'machine-config': {'vcpu_count': 1,
            'mem_size_mib': 512 if args.work_mib == 256 else 256,
            'smt': False, 'track_dirty_pages': True}}))
    original, sock, log = start_vmm('original', config)
    text = wait_log(original, log, 'DIRTY_WORKSET_READY')
    result['guest_cpu'] = re.search(r'GUEST_CPU pku=\d+ ospke=\d+ xcr0=0x[0-9a-f]+', text).group()
    api(sock, 'PATCH', '/vm', {'state': 'Paused'})
    api(sock, 'PUT', '/snapshot/create', {'snapshot_type': 'Full',
        'snapshot_path': str(memory / 'full.state'), 'mem_file_path': str(memory / 'full.mem')})
    api(sock, 'PATCH', '/vm', {'state': 'Resumed'})
    text = phase(original, 'dirty', b'W', log, 'DIRTY_FIRST_SWEEP_DONE')
    result['first_write_us'] = int(re.search(r'DIRTY_FIRST_SWEEP_DONE pages=\d+ us=(\d+)', text).group(1))
    api(sock, 'PATCH', '/vm', {'state': 'Paused'})
    api(sock, 'PUT', '/snapshot/create', {'snapshot_type': 'Diff',
        'snapshot_path': str(memory / 'diff.state'), 'mem_file_path': str(memory / 'diff.mem')})
    result['diff_alloc_bytes'] = (memory / 'diff.mem').stat().st_blocks * 512
    original.terminate()
    original.wait(timeout=10)
    shutil.copyfile(memory / 'full.mem', memory / 'merged.mem')
    merge = subprocess.check_output([str(ROOT / 'merge-sparse'),
                                    str(memory / 'merged.mem'), str(memory / 'diff.mem')], text=True)
    result['merge_output'] = merge.strip()
    restored, rsock, rlog = start_vmm('restored')
    deadline = time.monotonic() + 10
    while not rsock.exists() and time.monotonic() < deadline:
        assert restored.poll() is None
        time.sleep(0.01)
    api(rsock, 'PUT', '/snapshot/load', {'snapshot_path': str(memory / 'diff.state'),
        'mem_backend': {'backend_type': 'File', 'backend_path': str(memory / 'merged.mem')},
        'track_dirty_pages': True, 'resume_vm': False})
    api(rsock, 'PATCH', '/vm', {'state': 'Resumed'})
    text = phase(restored, 'restore', b'R', rlog, 'DIRTY_PROBE_FINISHED')
    matches = re.findall(r'DIRTY_VERIFY_OK epoch=(\d+) pages=(\d+) us=(\d+)', text)
    assert len(matches) == 2
    assert [int(v[0]) for v in matches] == [0, 1]
    assert all(int(v[1]) == args.work_mib * 256 for v in matches)
    result['cold_read_us'], result['warm_read_us'] = [int(v[2]) for v in matches]
    result['all_pages_restore_verified'] = True
    result['new_vmm_process'] = original.pid != restored.pid
    result['status'] = 'PASS'
except Exception as error:
    result['status'] = 'FAIL'
    result['error'] = type(error).__name__ + ': ' + str(error)
    raise
finally:
    for proc, output in processes:
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()
        output.close()
    (case / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    subprocess.run(['dmesg'], stdout=(case / 'host.dmesg').open('w'), check=True)
    shutil.rmtree(memory)
    print('RESULT ' + json.dumps(result), flush=True)
