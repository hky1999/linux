#!/usr/bin/env bash
set -Eeuo pipefail
root=$(cd "$(dirname "$0")" && pwd)
mkdir -p "$root/guest-root/bin" "$root/guest-root/dev" "$root/guest-root/proc"
cp /usr/bin/busybox "$root/guest-root/bin/busybox"
ln -sf busybox "$root/guest-root/bin/sh"
musl-gcc -static -O2 -Wall -Wextra "$root/dirty-writer.c" -o "$root/guest-root/bin/dirty-writer"
musl-gcc -static -O2 -Wall -Wextra "$root/../merge-sparse.c" -o "$root/merge-sparse"
cat > "$root/guest-root/init" <<'GUEST_INIT'
#!/bin/sh
/bin/busybox mount -t proc proc /proc
/bin/busybox mount -t devtmpfs devtmpfs /dev
work=$(/bin/busybox sed -n 's/.*work_mib=\([0-9]*\).*/\1/p' /proc/cmdline)
dirty=$(/bin/busybox sed -n 's/.*dirty_mib=\([0-9]*\).*/\1/p' /proc/cmdline)
exec /bin/dirty-writer "$work" "$dirty" </dev/ttyS0 >/dev/ttyS0 2>&1
GUEST_INIT
chmod +x "$root/guest-root/init"
(cd "$root/guest-root"; find . -print0 | cpio --null -o --format=newc --quiet > "$root/dirty-guest-initrd.cpio")
sha256sum "$root/dirty-guest-initrd.cpio" "$root/merge-sparse"
