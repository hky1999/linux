#define _GNU_SOURCE
#include <cpuid.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <termios.h>
#include <time.h>
#include <unistd.h>

static long long delta_us(struct timespec a, struct timespec b)
{
    return (b.tv_sec-a.tv_sec)*1000000LL+(b.tv_nsec-a.tv_nsec)/1000;
}

static void wait_command(char wanted)
{
    char c;
    for (;;) {
        ssize_t n=read(STDIN_FILENO,&c,1);
        if (n==1 && c==wanted) return;
        if (n<0 && errno!=EINTR) { perror("command"); _exit(2); }
    }
}

int main(int argc, char **argv)
{
    if (argc!=3) return 2;
    unsigned long work=strtoul(argv[1],NULL,10), dirty=strtoul(argv[2],NULL,10);
    if (!work || work>256 || dirty>work) return 2;
    struct termios tty;
    if (tcgetattr(STDIN_FILENO,&tty)==0) {
        cfmakeraw(&tty);
        if (tcsetattr(STDIN_FILENO,TCSANOW,&tty)) return 2;
    }
    unsigned int a,b,c,d;
    __cpuid_count(7,0,a,b,c,d);
    unsigned int pku=(c>>3)&1, ospke=(c>>4)&1;
    unsigned int lo,hi;
    __asm__ volatile("xgetbv" : "=a"(lo),"=d"(hi) : "c"(0));
    printf("GUEST_CPU pku=%u ospke=%u xcr0=0x%llx\n",pku,ospke,
           ((unsigned long long)hi<<32)|lo);
    size_t pages=work*1024*1024/4096, dirty_pages=dirty*1024*1024/4096;
    volatile unsigned char *mem=mmap(NULL,pages*4096,PROT_READ|PROT_WRITE,
        MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
    if (mem==MAP_FAILED) { perror("mmap"); return 2; }
    if (madvise((void *)mem,pages*4096,MADV_NOHUGEPAGE) && errno!=EINVAL) {
        perror("madvise"); return 2;
    }
    for (size_t i=0;i<pages;i++) mem[i*4096]=0x11;
    printf("DIRTY_WORKSET_READY mib=%lu pages=%zu dirty_mib=%lu\n",work,pages,dirty);
    fflush(stdout);
    wait_command('W');
    struct timespec start,end;
    clock_gettime(CLOCK_MONOTONIC,&start);
    for (size_t i=0;i<dirty_pages;i++) mem[i*4096]=0x4b;
    clock_gettime(CLOCK_MONOTONIC,&end);
    printf("DIRTY_FIRST_SWEEP_DONE pages=%zu us=%lld\n",dirty_pages,delta_us(start,end));
    fflush(stdout);
    wait_command('R');
    for (unsigned int epoch=0;epoch<2;epoch++) {
        clock_gettime(CLOCK_MONOTONIC,&start);
        for (size_t i=0;i<pages;i++) {
            unsigned char expected=i<dirty_pages?0x4b:0x11;
            if (mem[i*4096]!=expected) {
                printf("DIRTY_VERIFY_BAD page=%zu got=%u expected=%u\n",i,mem[i*4096],expected);
                fflush(stdout); return 1;
            }
        }
        clock_gettime(CLOCK_MONOTONIC,&end);
        printf("DIRTY_VERIFY_OK epoch=%u pages=%zu us=%lld\n",epoch,pages,delta_us(start,end));
        fflush(stdout);
    }
    printf("DIRTY_PROBE_FINISHED\n"); fflush(stdout);
    for (;;) pause();
}
