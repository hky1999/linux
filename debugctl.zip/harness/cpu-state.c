#include <cpuid.h>
#include <stdio.h>
int main(void)
{
    unsigned int a,b,c,d,lo,hi;
    __cpuid_count(7,0,a,b,c,d);
    unsigned int pku=(c>>3)&1, ospke=(c>>4)&1;
    __asm__ volatile("xgetbv" : "=a"(lo),"=d"(hi) : "c"(0));
    printf("CPU_STATE pku=%u ospke=%u xcr0=0x%llx\n",pku,ospke,
           ((unsigned long long)hi<<32)|lo);
    return 0;
}
