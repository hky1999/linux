#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>

#ifndef SEEK_DATA
#define SEEK_DATA 3
#define SEEK_HOLE 4
#endif

int main(int argc, char **argv)
{
    if (argc != 3) return 2;
    int base = open(argv[1], O_WRONLY);
    int diff = open(argv[2], O_RDONLY);
    if (base < 0 || diff < 0) { perror("open"); return 2; }
    struct stat base_st, diff_st;
    if (fstat(base, &base_st) || fstat(diff, &diff_st) ||
        base_st.st_size != diff_st.st_size) {
        perror("fstat/size"); return 2;
    }
    char buffer[1024 * 1024];
    off_t cursor = 0;
    unsigned long long copied = 0;
    while (cursor < diff_st.st_size) {
        off_t data = lseek(diff, cursor, SEEK_DATA);
        if (data == -1 && errno == ENXIO) break;
        if (data == -1) { perror("SEEK_DATA"); return 2; }
        off_t hole = lseek(diff, data, SEEK_HOLE);
        if (hole == -1) { perror("SEEK_HOLE"); return 2; }
        for (off_t at = data; at < hole;) {
            size_t count = (size_t)(hole - at);
            if (count > sizeof(buffer)) count = sizeof(buffer);
            ssize_t got = pread(diff, buffer, count, at);
            if (got <= 0) { perror("pread"); return 2; }
            ssize_t written = pwrite(base, buffer, (size_t)got, at);
            if (written != got) { perror("pwrite"); return 2; }
            at += got;
            copied += (unsigned long long)got;
        }
        cursor = hole;
    }
    printf("DIFF_MERGED_BYTES=%llu\n", copied);
    close(base);
    close(diff);
    return 0;
}
